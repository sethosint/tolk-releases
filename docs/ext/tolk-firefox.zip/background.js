// Tolk — перевод вкладки (Firefox). В Firefox нет захвата вкладки целиком, поэтому по щелчку на значке
// в страницу добавляется capture.js: он берёт звук её видео, аудио и созвонов и шлёт сюда, а отсюда —
// в Tolk (WebSocket на этот же компьютер, 127.0.0.1:47631). Повторный щелчок — выключить.

const t = (key) => browser.i18n.getMessage(key) || key;       // подсказки — на языке браузера

const TOLK = "ws://127.0.0.1:47631/tab";
let active = null;            // {tabId, port, ws}

async function badge(tabId, text, color, title) {
  try {
    await browser.action.setBadgeText({ tabId, text });
    if (color) await browser.action.setBadgeBackgroundColor({ tabId, color });
    await browser.action.setTitle({ tabId, title });
  } catch (e) { /* вкладку уже закрыли */ }
}

function stop() {
  if (!active) return;
  const { tabId, port, ws } = active;
  active = null;
  try { port.postMessage({ type: "stop" }); } catch (e) {}
  try { port.disconnect(); } catch (e) {}
  try { ws.close(); } catch (e) {}
  badge(tabId, "", null, t("titleIdle"));
}

browser.action.onClicked.addListener(async (tab) => {
  const same = active && active.tabId === tab.id;
  stop();
  if (same) return;
  try {
    await browser.scripting.executeScript({ target: { tabId: tab.id }, files: ["capture.js"] });
    badge(tab.id, "…", "#8a7550", t("titleConnecting"));
  } catch (e) {
    badge(tab.id, "!", "#b85c5c", t("titleNoCapture"));
  }
});

browser.runtime.onConnect.addListener((port) => {
  if (port.name !== "tolk-audio" || !port.sender || !port.sender.tab) return;
  const tabId = port.sender.tab.id;
  const ws = new WebSocket(TOLK);
  ws.binaryType = "arraybuffer";
  active = { tabId, port, ws };
  let hello = null, opened = false;
  ws.onopen = () => {
    opened = true;
    if (hello) ws.send(JSON.stringify(hello));
    badge(tabId, "ON", "#c9a86a", t("titleOn"));
  };
  ws.onclose = () => {
    if (!active || active.ws !== ws) return;
    stop();
    if (!opened) badge(tabId, "!", "#b85c5c", t("titleNoApp"));
  };
  port.onMessage.addListener((m) => {
    if (m && m.hello) {
      hello = m;
      if (opened) ws.send(JSON.stringify(m));
    } else if (m instanceof ArrayBuffer && opened && ws.bufferedAmount < 2000000) {
      ws.send(m);
    }
  });
  port.onDisconnect.addListener(() => { if (active && active.port === port) stop(); });
});

browser.tabs.onRemoved.addListener((tabId) => { if (active && active.tabId === tabId) stop(); });
