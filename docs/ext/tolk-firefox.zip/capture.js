// Tolk (Firefox): звук видео, аудио и созвонов этой страницы → расширение → Tolk. Страница продолжает звучать
// как обычно. Защищённое (DRM) и чужое без разрешения (CORS) видео не трогаем — иначе оно замолчало бы.
(() => {
  const T = (window.__tolk = window.__tolk || {});
  if (T.port) return;                                        // уже слушаем
  if (!T.ctx) {
    T.ctx = new AudioContext();
    T.mix = T.ctx.createGain();
    T.hooked = new WeakSet();
    T.streams = new WeakMap();
  }
  const ctx = T.ctx;
  ctx.resume().catch(() => {});
  const port = browser.runtime.connect({ name: "tolk-audio" });
  T.port = port;
  port.postMessage({ hello: "tolk-tab", rate: ctx.sampleRate, title: document.title || location.host });

  const proc = ctx.createScriptProcessor(4096, 2, 1);
  proc.onaudioprocess = (e) => {
    if (T.port !== port) return;
    const a = e.inputBuffer.getChannelData(0);
    const b = e.inputBuffer.numberOfChannels > 1 ? e.inputBuffer.getChannelData(1) : a;
    const mono = new Float32Array(a.length);
    for (let i = 0; i < a.length; i++) mono[i] = (a[i] + b[i]) / 2;
    try { port.postMessage(mono.buffer); } catch (err) {}
  };
  T.mix.connect(proc);
  proc.connect(ctx.destination);                             // выход процессора — тишина, нужен только для работы

  function sameOrigin(el) {
    const src = el.currentSrc || el.src || "";
    if (!src || src.startsWith("blob:") || src.startsWith("data:")) return true;
    try { return new URL(src, location.href).origin === location.origin || el.crossOrigin != null; } catch (e) { return false; }
  }

  function hook(el) {
    try {
      if (el.srcObject instanceof MediaStream) {             // созвоны (WebRTC): элемент играет сам, берём копию
        if (T.streams.get(el) === el.srcObject) return;
        T.streams.set(el, el.srcObject);
        if (el.srcObject.getAudioTracks().length) ctx.createMediaStreamSource(el.srcObject).connect(T.mix);
        return;
      }
      if (T.hooked.has(el) || el.mediaKeys || !sameOrigin(el)) return;
      if (ctx.state !== "running") return;                  // звук страницы ещё не разрешён — иначе элемент замолчал бы
      T.hooked.add(el);
      const s = ctx.createMediaElementSource(el);            // звук элемента теперь идёт через Tolk…
      s.connect(ctx.destination);                            // …и дальше в колонки, как раньше
      s.connect(T.mix);
    } catch (e) { /* такой элемент захватить нельзя — оставляем как есть */ }
  }

  const scan = () => document.querySelectorAll("audio, video").forEach(hook);
  if (ctx.state !== "running") {                             // звук разрешится после первого щелчка или клавиши на странице
    const wake = () => ctx.resume().then(scan, () => {});
    document.addEventListener("pointerdown", wake, { capture: true, once: true });
    document.addEventListener("keydown", wake, { capture: true, once: true });
  }
  ctx.addEventListener("statechange", scan);
  scan();
  const obs = new MutationObserver(scan);
  obs.observe(document.documentElement, { childList: true, subtree: true });
  const timer = setInterval(scan, 2000);                     // созвоны подставляют звук позже

  function stop() {
    if (T.port !== port) return;
    T.port = null;
    clearInterval(timer);
    obs.disconnect();
    try { T.mix.disconnect(proc); proc.disconnect(); } catch (e) {}
    try { port.disconnect(); } catch (e) {}
  }
  port.onMessage.addListener((m) => { if (m && m.type === "stop") stop(); });
  port.onDisconnect.addListener(stop);
})();
