// Tolk — перевод вкладки. Щелчок по значку на вкладке: её звук уходит в Tolk (он должен быть запущен),
// повторный щелчок на той же вкладке — выключить. Звук вкладки при этом продолжает играть как обычно.
// Звук принимает невидимая страница расширения (offscreen); в Chromium-браузере без offscreen — та же страница
// фоновой закреплённой вкладкой «Tolk» (закрывается сама при выключении).

const t = (key) => chrome.i18n.getMessage(key) || key;       // подсказки — на языке браузера

const OFFSCREEN = "offscreen.html";
const hasOffscreen = () => Boolean(chrome.offscreen && chrome.offscreen.createDocument);

async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument?.()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN,
    reasons: ["USER_MEDIA"],
    justification: "Capture the chosen tab's sound for Tolk live subtitles",
  });
}

// запасной путь: вкладка с той же страницей; ждём, пока она скажет «готова»
let readyWait = null;
async function ensureCaptureTab(windowId) {
  const { cap } = await chrome.storage.session.get("cap");
  if (cap != null) {
    try { await chrome.tabs.get(cap); return cap; } catch (e) { /* закрыли — откроем новую */ }
  }
  const ready = new Promise((res) => { readyWait = res; setTimeout(res, 4000); });
  const tab = await chrome.tabs.create({ url: OFFSCREEN + "?tab=1", active: false, pinned: true, windowId });
  await chrome.storage.session.set({ cap: tab.id });
  await ready;
  return tab.id;
}

async function badge(tabId, text, color, title) {
  if (tabId == null) return;
  try {
    await chrome.action.setBadgeText({ tabId, text });
    if (color) await chrome.action.setBadgeBackgroundColor({ tabId, color });
    await chrome.action.setTitle({ tabId, title });
  } catch (e) { /* вкладку уже закрыли */ }
}

async function current() {
  return (await chrome.storage.session.get("tab")).tab ?? null;
}

async function stop() {
  const tab = await current();
  await chrome.storage.session.remove("tab");
  try { await chrome.runtime.sendMessage({ target: "offscreen", type: "stop" }); } catch (e) { /* слушать некому */ }
  const { cap } = await chrome.storage.session.get("cap");
  if (cap != null) {
    await chrome.storage.session.remove("cap");
    try { await chrome.tabs.remove(cap); } catch (e) { /* уже закрыта */ }
  }
  await badge(tab, "", null, t("titleIdle"));
}

chrome.action.onClicked.addListener(async (tab) => {
  if ((await current()) === tab.id) {
    await stop();
    return;
  }
  try {
    await stop();
    let streamId;
    if (hasOffscreen()) {
      streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
      await ensureOffscreen();
    } else {
      const cap = await ensureCaptureTab(tab.windowId);
      streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id, consumerTabId: cap });
    }
    await chrome.storage.session.set({ tab: tab.id });
    const info = await chrome.tabs.get(tab.id).catch(() => tab);         // после щелчка (activeTab) видно название вкладки
    chrome.runtime.sendMessage({ target: "offscreen", type: "start", streamId, title: info.title || tab.title || "", tabId: tab.id }).catch(() => {});
    await badge(tab.id, "…", "#8a7550", t("titleConnecting"));
  } catch (e) {
    await badge(tab.id, "!", "#b85c5c", t("titleFail") + " — " + (e && e.message ? e.message : e));
  }
});

chrome.runtime.onMessage.addListener((m) => {
  if (m.target !== "background") return;
  if (m.type === "ready") { if (readyWait) readyWait(); readyWait = null; return; }
  (async () => {
    const tab = await current();
    if (m.type === "connected") await badge(tab, "ON", "#c9a86a", t("titleOn"));
    if (m.type === "no_tolk") {
      await chrome.storage.session.remove("tab");
      await badge(tab, "!", "#b85c5c", t("titleNoApp"));
    }
    if (m.type === "ended") {
      await chrome.storage.session.remove("tab");
      await badge(tab, "", null, t("titleIdle"));
    }
  })();
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if ((await current()) === tabId) await stop();
  const { cap } = await chrome.storage.session.get("cap");
  if (cap === tabId) {                                   // закрыли вкладку «Tolk» запасного пути — перевод выключен
    await chrome.storage.session.remove("cap");
    await stop();
  }
});
