// Невидимая страница расширения: получает звук вкладки, оставляет его слышимым и отправляет в Tolk
// (WebSocket на этот же компьютер, 127.0.0.1:47631) — моно float32 кусками по 0,1 с.

const TOLK = "ws://127.0.0.1:47631/tab";
let ctx = null, stream = null, ws = null, node = null;

function tell(type) {
  chrome.runtime.sendMessage({ target: "background", type });
}

function stop(reason) {
  try { if (ws) ws.close(); } catch (e) {}
  try { if (node) node.disconnect(); } catch (e) {}
  try { if (stream) stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
  try { if (ctx) ctx.close(); } catch (e) {}
  ws = stream = node = ctx = null;
  if (reason) tell(reason);
}

async function start(m) {
  stop();
  stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: m.streamId } },
    video: false,
  });
  ctx = new AudioContext();
  const src = ctx.createMediaStreamSource(stream);
  src.connect(ctx.destination);                         // вкладку по-прежнему слышно
  await ctx.audioWorklet.addModule("pcm.js");
  node = new AudioWorkletNode(ctx, "tolk-pcm");
  src.connect(node);
  const rate = ctx.sampleRate;
  const sock = new WebSocket(TOLK);
  sock.binaryType = "arraybuffer";
  ws = sock;
  let opened = false;
  sock.onopen = () => {
    opened = true;
    sock.send(JSON.stringify({ hello: "tolk-tab", rate, title: m.title || "" }));
    tell("connected");
  };
  sock.onclose = () => {
    if (ws !== sock) return;                            // уже переключились на другую вкладку
    stop(opened ? "ended" : "no_tolk");
  };
  node.port.onmessage = (e) => {
    if (ws === sock && sock.readyState === WebSocket.OPEN && sock.bufferedAmount < 2000000) sock.send(e.data);
  };
  stream.getAudioTracks().forEach((t) => (t.onended = () => stop("ended")));
}

chrome.runtime.onMessage.addListener((m) => {
  if (m.target !== "offscreen") return;
  if (m.type === "start") start(m).catch(() => stop("no_tolk"));
  if (m.type === "stop") stop();
});
if (location.search.includes("tab=1")) {                 // запасной путь (браузер без offscreen): вкладка «Tolk»
  document.title = "Tolk";
  document.body.style.cssText = "font: 15px system-ui, sans-serif; color: #888; padding: 2rem";
  document.body.append(chrome.i18n.getMessage("tabKeep") || "Tolk");
  tell("ready");
}
